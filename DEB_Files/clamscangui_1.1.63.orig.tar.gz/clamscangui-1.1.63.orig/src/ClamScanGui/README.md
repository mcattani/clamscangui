# clamscangui
Última versión: 1.1.60

Repositorio de la interfaz gráfica para el antivirus ClamAV hecho en Gambas.

El ClamAV es un poderoso antivirus open source que detecta: troyanos, virus, malware y otros amenazas.

    ClamAV® is an open source antivirus engine for detecting trojans, viruses, malware & other malicious threats.

Pueden descargarlo desde su página oficial: https://www.clamav.net/

Antiguamente estaba utilizando una interfaz gráfica bastante conocida: ClamTK (excelente programa). Pero me parecía que había posibilidades de hacerlo de otra manera. 
Y por qué no?

Dentro de la carpeta DEB_Files están el archivo .deb para su instalación en Debian y derivados.

Ver el archivo ChangeLog para ver los cambios realizados. 

Gracias a Philippe Valarcher por los aportes realizados.


